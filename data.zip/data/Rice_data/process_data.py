#!/home/hcyao/miniconda/bin/python 
import sys
from Bio import SeqIO
f=sys.argv[1]
for record in SeqIO.parse(f,"fasta"):
        name=record.id[:16]
        print(">"+name)
        print(record.seq)
