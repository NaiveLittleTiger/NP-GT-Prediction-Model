import sys
from Bio import SeqIO
import pandas as pd
f=sys.argv[1]
f1=sys.argv[2]
f1=pd.read_csv(f1,sep='\t')
rice_gt1=f1['Rice_name'].to_list()
print(rice_gt1)
for record in SeqIO.parse(f,"fasta"):
    name=record.id[:16]
    #print(name[0:])
#    for i in rice_gt1:
        #print(i)
#        if name[0:] == i:
#            print(">"+name)
#            print(record.seq)    

